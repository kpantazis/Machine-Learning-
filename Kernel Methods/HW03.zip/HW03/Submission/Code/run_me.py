import numpy as np
import kaggle
from sklearn.metrics import accuracy_score

##############################################################################################
# Read in train and test synthetic data
def load_synthetic_data():
        print('Reading synthetic data ...')
        train_x = np.loadtxt('../../Data/Synthetic/data_train.txt', delimiter = ',', dtype=float)
        train_y = np.loadtxt('../../Data/Synthetic/label_train.txt', delimiter = ',', dtype=float)
        test_x = np.loadtxt('../../Data/Synthetic/data_test.txt', delimiter = ',', dtype=float)
        test_y = np.loadtxt('../../Data/Synthetic/label_test.txt', delimiter = ',', dtype=float)

        return (train_x, train_y, test_x, test_y)
###############################################################################################

################################################################
# load currency data
def load_currency_data():
	train_x = np.load('../../Data/Currency/train_x.npy')
	train_y = np.load('../../Data/Currency/train_y.npy')
	test_x = np.load('../../Data/Currency/test_x.npy')
	return train_x, train_y, test_x
################################################################

################################################################
# load shellfish data
def load_shellfish_data():
	train_x = np.load('../../Data/Shellfish/train_x.npy')
        train_y = np.load('../../Data/Shellfish/train_y.npy')
        test_x = np.load('../../Data/Shellfish/test_x.npy')
        return train_x, train_y, test_x
################################################################

################################################################
# Compute MSE
def compute_MSE(y, y_hat):
        # mean squared error
        return np.mean(np.power(y - y_hat, 2))
################################################################

train_x, train_y, test_x, test_y = load_synthetic_data()
print('Train=', train_x.shape)
print('Test=', test_x.shape)

# get the shellfish data
train_x, train_y, test_x = load_shellfish_data()
print('train data shape: ', train_x.shape)
print('train label shape: ', train_y.shape)
print('test data shape: ', test_x.shape)


# Create dummy test output values to compute MSE
test_y = np.random.rand(len(test_x))
predicted_y = np.random.rand(len(test_y))
print('DUMMY MSE=%0.4f' % compute_MSE(test_y, predicted_y))

# Output file location
file_name = '../Predictions/Shellfish/best.csv'
# Writing output in Kaggle format
print('Writing output to ', file_name)
kaggle.kaggleize(predicted_y, file_name, True)

train_x, train_y, test_x  = load_currency_data()
print('Train=', train_x.shape)
print('Test=', test_x.shape)

# Create dummy test output values to compute accuracy
test_y = np.random.randint(0, 2, (test_x.shape[0], 1))
predicted_y = np.random.randint(0, 2, (test_x.shape[0], 1))
print('DUMMY Accuracy=%0.4f' % accuracy_score(test_y, predicted_y, normalize=True))

# Output file location
file_name = '../Predictions/Currency/best.csv'
# Writing output in Kaggle format
print('Writing output to ', file_name)
kaggle.kaggleize(predicted_y, file_name, False)
