import numpy as np
import matplotlib.pyplot as plt

def get_data(filename):
    f = open(filename, 'r')
    f_x = f.readlines()
    f.close()
    f_x = [x.strip('\n') for x in f_x]
    f_x = [float(x) for x in f_x]
    f_x = np.array(f_x)
    return f_x

def dataloader():
    train_x = get_data('../../Data/x.csv')
    train_y = get_data('../../Data/y.csv')
    test_x = get_data('../../Data/x_test.csv')
    test_y = get_data('../../Data/y_test.csv')
    return train_x, train_y, test_x, test_y

def error(preds, gt):
    error = gt-preds
    error_square = np.power(error, 2)
    mse = np.sum(error_square)/100.0
    return mse

train_x, train_y, test_x, test_y = dataloader()
print train_x.shape, train_y.shape, test_x.shape, test_y.shape
