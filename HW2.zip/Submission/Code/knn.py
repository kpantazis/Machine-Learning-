# -*- coding: utf-8 -*-
"""
@author: Pantazis
"""
#Load Libraries
import numpy as np
import sklearn
import kaggle
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt

# Read in train and test data
def read_image_data():
	print('Reading image data ...')
	train_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_train.npy')
	train_y = np.load('C:/Users/Pantazis/Desktop/HW02/Data/train_labels.npy')
	test_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_test.npy')

	return (train_x, train_y, test_x)
#CrossValidation
def est_out_of_sample_error(k, data):
    train_x, train_y, test_x = data
    sample_error=0
    kfold = KFold(5,True,1)
    for train_index, eval_index in kfold.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(x_train , y_train)
        print(k)
        predicted_y_eval = model.predict(x_eval)
        sample_error += compute_error(accuracy_score(predicted_y_eval, y_eval,normalize=True)) 

    sample_error /= 5
    return (sample_error)
    #Get errors for each parameter
def get_results(ks, data):
    train_x, train_y, test_x = data
    sample_errors = []
    for k in ks:
        sample_error = est_out_of_sample_error(k, data)
        sample_errors.append(sample_error)
    return ks, sample_errors
#kaggle output
def kaggle_predictions(results, data):
    train_x, train_y, test_x = data
    ks, sample_errors = results
    best_k = ks[np.argmin(sample_errors)]     

    model = KNeighborsClassifier(n_neighbors=best_k,n_jobs=-1)
    model.fit(train_x , train_y)
    predict_output = model.predict(test_x)
    kaggle.kaggleize(predict_output, "C:/Users/Pantazis/Desktop/HW02/Submission/Predictions/knn.csv")
# make figure & table
def figures(results):
    ks, sample_errors = results
    #error
    plt.clf()
    fig, ax = plt.subplots()
    titles = ("k", "Estimated Out of Sample Error")
    fig.patch.set_visible(False)
    ax.axis("off")
    ax.table(cellText=np.column_stack([ks, sample_errors]), colLabels=titles, loc="center")
    fig.patch.set_visible(True)
    ax.axis("on")
    plt.savefig("C:/Users/Pantazis/Desktop/HW02/Submission/Figures/knn_errors.png")
    

def run_data_image_2():
    data = read_image_data()
    ks = [3, 5, 7, 9, 11]
    results = get_results(ks, data)
    kaggle_predictions(results, data)
    figures(results)

#def run_question_1():
 #   run_question_1()    
#Compute error
def compute_error(accuracy):
    return 1-accuracy

run_data_image_2()