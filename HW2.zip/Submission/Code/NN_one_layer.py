import autograd.numpy as np
import autograd
from autograd.misc import flatten
from sklearn.model_selection import StratifiedKFold
import time
import matplotlib.pyplot as plt
import kaggle
import random


# Function to compute classification accuracy
def mean_zero_one_loss(weights, x, y_integers, unflatten):
	(W, b, V, c) = unflatten(weights)
	out = feedForward(W, b, V, c, x)
	pred = np.argmax(out, axis=1)
	return(np.mean(pred != y_integers))

# Feed forward output i.e. L = -O[y] + log(sum(exp(O[j])))
def feedForward(W, b, V, c, train_x):
        hid = np.tanh(np.dot(train_x, W) + b)
        out = np.dot(hid, V) + c
        return out

# Logistic Loss function
def logistic_loss_batch(weights, x, y, unflatten):
	# regularization penalty
        lambda_pen = 10

        # unflatten weights into W, b, V and c respectively 
        (W, b, V, c) = unflatten(weights)

        # Predict output for the entire train data
        out  = feedForward(W, b, V, c, x)
        pred = np.argmax(out, axis=1)

	# True labels
        true = np.argmax(y, axis=1)
        # Mean accuracy
        class_err = np.mean(pred != true)

        # Computing logistic loss with l2 penalization
        logistic_loss = np.sum(-np.sum(out * y, axis=1) + np.log(np.sum(np.exp(out),axis=1))) + lambda_pen * np.sum(weights**2)
        
        # returning loss. Note that outputs can only be returned in the below format
        return (logistic_loss, [autograd.tracer.getval(logistic_loss), autograd.tracer.getval(class_err)])

# Loading the dataset

print('Reading image data ...')
temp = np.load('../../Data/data_train.npy')
train_x = temp
temp = np.load('../../Data/train_labels.npy')
train_y_integers = temp
temp = np.load('../../Data/data_test.npy')
test_x = temp

# Make inputs approximately zero mean (improves optimization backprob algorithm in NN)
train_x = train_x.astype(float)
test_x = test_x.astype(float)
train_x /= 255
test_x /= 255
train_x -= .5
test_x  -= .5

# Number of output dimensions
dims_out = 4
# Number of hidden units
dims_hid = np.array([5, 40, 70])
# Learning rate
epsilon = 0.0001
# Momentum of gradients update
momentum = 0.1
# Number of epochs
nEpochs = 1000
# Number of train examples
nTrainSamples = train_x.shape[0]
# Number of input dimensions
dims_in = train_x.shape[1]

# Convert integer labels to one-hot vectors
# i.e. convert label 2 to 0, 0, 1, 0
train_y = np.zeros((nTrainSamples, dims_out))
train_y[np.arange(nTrainSamples), train_y_integers] = 1

assert momentum <= 1
assert epsilon <= 1

# Batch compute the gradients (partial derivatives of the loss function w.r.t to all NN parameters)
grad_fun = autograd.grad_and_aux(logistic_loss_batch)

def trainNN(dims_in, dims_hid, dims_out, epsilon, momentum, nTrainSamples, nEpochs, train_x, train_y):
        # Initializing weights
        W = np.random.randn(dims_in, dims_hid)
        b = np.random.randn(dims_hid)
        V = np.random.randn(dims_hid, dims_out)
        c = np.random.randn(dims_out)
        smooth_grad = 0

        # Compress all weights into one weight vector using autograd's flatten
        all_weights = (W, b, V, c)
        weights, unflatten = flatten(all_weights)
        
        lossValue = np.zeros(nEpochs)

        for i in range(nEpochs):
                # Compute gradients (partial derivatives) using autograd toolbox
                weight_gradients, returned_values = grad_fun(weights, train_x, train_y, unflatten)
                lossValue[i] = returned_values[0] 
                print('logistic loss: ', returned_values[0], 'Train error =', returned_values[1])

                # Update weight vector
                smooth_grad = (1 - momentum) * smooth_grad + momentum * weight_gradients
                weights = weights - epsilon * smooth_grad

                print('Train accuracy =', 1-mean_zero_one_loss(weights, train_x, train_y_integers, unflatten))


        return lossValue , 1-mean_zero_one_loss(weights, train_x, train_y_integers, unflatten)


values = np.zeros((len(dims_hid), nEpochs))
myTime = np.zeros(len(dims_hid))

for j in range(len(dims_hid)):
        startTime = time.time()
        values[j, :] , accuracy = trainNN(dims_in, dims_hid[j], dims_out, epsilon, momentum, nTrainSamples, nEpochs, train_x, train_y)
        endTime = time.time()
        myTime[j] = (endTime-startTime)*1000


inds = np.arange(nEpochs)
labels = ["h=5","h=40","h=70"]
#Plot a line graph
plt.figure(1, figsize=(6,4))  #6x4 is the aspect ratio for the plot
plt.plot(inds,values[0,:],'or-', linewidth=3) #Plot the first series in red with circle marker
plt.plot(inds,values[1,:],'sb-', linewidth=3) #Plot the first series in blue with square marker
plt.plot(inds,values[2,:],'*k-', linewidth=3) #Plot the first series in blue with square marker

#This plots the data
plt.grid(True) #Turn the grid on
plt.ylabel("Logistic Loss") #Y-axis label
plt.xlabel("M") #X-axis label
plt.title("Loss vs M-value") #Plot title
#plt.xlim(-0.1,4.1) #set x axis range
#plt.ylim(0,1) #Set yaxis range
plt.legend(labels, loc="best")

#Save the chart
plt.savefig("../Figures/loss1.png")


inds = np.arange(len(dims_hid))
#labels = ["h=5","h=40","h=70"]
#Plot a bar chart
plt.figure(2, figsize=(6,4))  #6x4 is the aspect ratio for the plot
plt.bar(inds, myTime, align='center') #This plots the data
plt.grid(True) #Turn the grid on
plt.ylabel("Error") #Y-axis label
plt.xlabel("Training Time") #X-axis label
plt.title("Training Time vs M-value") #Plot title
#plt.xlim(-0.5,2.5) #set x axis range
#plt.ylim(0,1) #Set yaxis range

#Set the bar labels
plt.gca().set_xticks(inds) #label locations
plt.gca().set_xticklabels(labels) #label values

#Save the chart
plt.savefig("../Figures/time1.png")

#Displays the plots.
#You must close the plot window for the code following each show()
#to continue to run
#plt.show()

#Displays the charts.
#You must close the plot window for the code following each show()
#to continue to run
#plt.show()
#Train-validation stratified split
def est_out_of_sample_error(dims_in, dims_hid, dims_out, epsilon, momentum, nTrainSamples, train_x, train_y,test_x):
    sample_error=0
    STF = StratifiedKFold(n_splits=5)
    random.seed(356)
    # Initializing weights
    W = np.random.randn(dims_in, dims_hid)
    b = np.random.randn(dims_hid)
    V = np.random.randn(dims_hid, dims_out)
    c = np.random.randn(dims_out)
    smooth_grad = 0

        # Compress all weights into one weight vector using autograd's flatten
    all_weights = (W, b, V, c)
    weights, unflatten = flatten(all_weights)

    for train_index, eval_index in STF.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        
        weight_gradients, returned_values = grad_fun(weights, x_train, y_train, unflatten)
                
        print('logistic loss: ', returned_values[0], 'Train error =', returned_values[1])

                # Update weight vector
        smooth_grad = (1 - momentum) * smooth_grad + momentum * weight_gradients
        weights = weights - epsilon * smooth_grad
        

        sample_error += mean_zero_one_loss(weights,x_eval, y_eval,unflatten) 
       # weight_gradients, returned_values = grad_fun(weights, train_x, train_y, unflatten)
        #print('logistic loss: ', returned_values[0], 'Train error =', returned_values[1])

        # Update weight vector
        #smooth_grad = (1 - momentum) * smooth_grad + momentum * weight_gradients
        #weights = weights - epsilon * smooth_grad

        #print('Train accuracy =', 1-mean_zero_one_loss(weights, train_x, train_y_integers, unflatten))
    sample_error /= 5
    print('Te sample ', sample_error)
    return (sample_error)

def get_results(dims_hid, train_x, train_y, test_x):
        sample_errors = []
        for k in dims_hid:
                sample_error , accuracy = est_out_of_sample_error(dims_in, dims_hid, dims_out, epsilon, momentum, nTrainSamples, train_x, train_y,test_x)
                sample_errors.append(sample_error) 
        return dims_hid, sample_errors


def kaggle_predictions(results, train_x, train_y, test_x):
    dims_hid ,  sample_errors = results 
    best_hid = dims_hid[np.argmin(sample_errors)]
    print(best_hid)          
    se , best_accuracy = trainNN(dims_in, best_hid, dims_out, epsilon, momentum, nTrainSamples, nEpochs, train_x, train_y)
    
    kaggle.kaggleize(best_accuracy, "C:/Users/Pantazis/Desktop/HW02/Submission/Predictions/NN_one_layer.csv")
# make figure & table
def figures(results):
    dims_hid, sample_errors = results
    #error
    plt.clf()
    fig, ax = plt.subplots()
    titles = ("hidden units", "Estimated Out of Sample Error")
    fig.patch.set_visible(False)
    ax.axis("off")
    ax.table(cellText=np.column_stack([dims_hid, sample_errors]), colLabels=titles, loc="center")
    fig.patch.set_visible(True)
    ax.axis("on")
    plt.savefig("C:/Users/Pantazis/Desktop/HW02/Submission/Figures/NN_one_layer_errors.png")
    

def run_data_image_4(train_x, train_y, test_x):
    
    ks = dims_hid
    results = get_results(ks, train_x, train_y, test_x)
    kaggle_predictions(results,train_x, train_y, test_x)
    figures(results)


run_data_image_4(train_x, train_y, test_x)