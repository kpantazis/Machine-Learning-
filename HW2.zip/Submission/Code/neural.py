import numpy as np
import sklearn
import kaggle
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from sklearn.neural_network import MLPClassifier
import matplotlib.pyplot as plt

# Read in train and test data
def read_image_data():
	print('Reading image data ...')
	train_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_train.npy')
	train_y = np.load('C:/Users/Pantazis/Desktop/HW02/Data/train_labels.npy')
	test_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_test.npy')

	return (train_x, train_y, test_x)

def kaggle_predictions(data):
    train_x, train_y, test_x = data
      

    model = MLPClassifier(hidden_layer_sizes=50)
    model.fit(train_x , train_y)
    predict_output = model.predict(test_x)
    kaggle.kaggleize(predict_output, "C:/Users/Pantazis/Desktop/HW02/Submission/Predictions/NN.csv")
# make figure & table
#def figures(results):
   # ks, sample_errors = results
    #error
   # plt.clf()
    #fig, ax = plt.subplots()
    #titles = ("k", "Estimated Out of Sample Error")
    #fig.patch.set_visible(False)
    #ax.axis("off")
    #ax.table(cellText=np.column_stack([ks, sample_errors]), colLabels=titles, loc="center")
    #fig.patch.set_visible(True)
    #ax.axis("on")
    #plt.savefig("C:/Users/Pantazis/Desktop/HW02/Submission/Figures/NN_errors.png")
    

def run_data_image_1():
    data = read_image_data()
  
    kaggle_predictions(data)
    #figures(results)

#def run_question_1():
 #   run_question_1()    
#Compute error
def compute_error(accuracy):
    return 1-accuracy

run_data_image_1()