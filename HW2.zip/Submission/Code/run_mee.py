import DecisionTrees
import knn
import linearmodel

#Question 1(Decision Trees)
DecisionTrees.run_data_image_1()
#Question 2(Nearest Neighbors)
knn.run_data_image_2()
#Question 3(Linear Model)
linearmodel.run_data_image_3
