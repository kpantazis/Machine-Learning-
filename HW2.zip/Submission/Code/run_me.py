# Import python modules
import numpy as np
import kaggle
from sklearn.metrics import accuracy_score

# Read in train and test data
def read_image_data():
	print('Reading image data ...')
	train_x = np.load('../../Data/data_train.npy')
	train_y = np.load('../../Data/train_labels.npy')
	test_x = np.load('../../Data/data_test.npy')

	return (train_x, train_y, test_x)

############################################################################

train_x, train_y, test_x = read_image_data()
print('Train=', train_x.shape)
print('Test=', test_x.shape)

# Create dummy test output values to compute accuracy
test_y = np.ones(test_x.shape[0])
predicted_y = np.random.randint(0, 4, test_x.shape[0])
print('DUMMY Accuracy=%0.4f' % accuracy_score(test_y, predicted_y, normalize=True))

# Output file location
file_name = '../Predictions/best.csv'
# Writing output in Kaggle format
print('Writing output to ', file_name)
kaggle.kaggleize(predicted_y, file_name)

import DecisionTrees
import knn
import linearmodel

#Question 1(Decision Trees)
DecisionTrees.run_data_image_1()
#Question 2(Nearest Neighbors)
knn.run_data_image_2()
#Question 3(Linear Model)
linearmodel.run_data_image_3


