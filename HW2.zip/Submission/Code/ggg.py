# -*- coding: utf-8 -*-
"""
@author: Pantazis
"""
#Load Libraries
import numpy as np
import sklearn
import kaggle
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt

# Read in train and test data
def read_image_data():
	print('Reading image data ...')
	train_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_train.npy')
	train_y = np.load('C:/Users/Pantazis/Desktop/HW02/Data/train_labels.npy')
	test_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_test.npy')

	return (train_x, train_y, test_x)
#CrossValidation
def est_out_of_sample_error(k_range,data):
    train_x, train_y, test_x = data
    for k in k_range:
        param_grid = dict(n_neighbors = k_range)
        grid=GridSearchCV(KNeighborsClassifier(n_neighbors=k,n_jobs=-1),param_grid,cv=5,scoring='accuracy')
        grid.fit(train_x,train_y)
        print(grid.best_estimator_)
    return grid.best_estimator_
    

def run_data_image_5():
    data = read_image_data()
    k_range = range(1,31)
    results = est_out_of_sample_error(k_range,data)

run_data_image_5