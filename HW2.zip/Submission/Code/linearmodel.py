# -*- coding: utf-8 -*-
"""
@author: Pantazis
"""
#Load Libraries
import numpy as np
import sklearn
import kaggle
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from sklearn.linear_model import SGDClassifier
import matplotlib.pyplot as plt

# Read in train and test data
def read_image_data():
	print('Reading image data ...')
	train_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_train.npy')
	train_y = np.load('C:/Users/Pantazis/Desktop/HW02/Data/train_labels.npy')
	test_x = np.load('C:/Users/Pantazis/Desktop/HW02/Data/data_test.npy')

	return (train_x, train_y, test_x)
#CrossValidation
def est_out_of_sample_error_1(alpha, data):
    train_x, train_y, test_x = data
    sample_error1=0
    kfold = KFold(5,True,1)
    for train_index, eval_index in kfold.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        model1 = SGDClassifier(alpha=alpha,l1_ratio=0,n_jobs=-1,max_iter=1000,tol=1e-3)
        model1.fit(x_train , y_train)
        print(alpha)
        predicted_y_eval_1 = model1.predict(x_eval)
        sample_error1 += compute_error(accuracy_score(predicted_y_eval_1, y_eval,normalize=True))  

    sample_error1 /= 5
    print(sample_error1)
    return (sample_error1)

def est_out_of_sample_error_2(alpha, data):
    train_x, train_y, test_x = data
    sample_error2=0
    kfold = KFold(5,True,1)
    for train_index, eval_index in kfold.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        model2 = SGDClassifier(loss="log",alpha=alpha,l1_ratio=0,n_jobs=-1,max_iter=1000,tol=1e-3)
        model2.fit(x_train , y_train)
        print(alpha)
        predicted_y_eval_2 = model2.predict(x_eval) 
        sample_error2 += compute_error(accuracy_score(predicted_y_eval_2, y_eval,normalize=True)) 

    sample_error2 /= 5
    print(sample_error2)
    return (sample_error2)
    #Get errors for each parameter
def get_results(alphas, data):
    train_x, train_y, test_x = data
    sample_errors1 = []
    sample_errors2 = []
    for alpha in alphas:
        sample_error1 = est_out_of_sample_error_1(alpha, data)
        sample_error2 = est_out_of_sample_error_2(alpha, data)
        sample_errors1.append(sample_error1)
        sample_errors2.append(sample_error2)
        print(sample_errors1,sample_errors2)
    return alphas, sample_errors1, sample_errors2
#kaggle output
def kaggle_predictions(results, data):
    train_x, train_y, test_x = data
    alphas, sample_errors1, sample_errors2 = results
    best_alpha_1=0
    best_alpha_2=0
    best_alpha_1=alphas[np.argmin(sample_errors1)]     
    best_alpha_2 = alphas[np.argmin(sample_errors2)] 
    model1 = SGDClassifier(alpha = best_alpha_1, l1_ratio = 0, n_jobs= -1, max_iter= 1000,tol= 1e-3)
    model1.fit(train_x , train_y)
    predict_output1 = model1.predict(test_x)
    model2 = SGDClassifier(loss="log",alpha=best_alpha_2,l1_ratio=0,n_jobs=-1,max_iter=1000,tol=1e-3)
    model2.fit(train_x , train_y)
    predict_output2 = model2.predict(test_x)
    kaggle.kaggleize(predict_output1, "C:/Users/Pantazis/Desktop/HW02/Submission/Predictions/linearmodel1.csv")
    kaggle.kaggleize(predict_output2, "C:/Users/Pantazis/Desktop/HW02/Submission/Predictions/linearmodel2.csv")
# make figure & table

def run_data_image_3():
    data = read_image_data()
    alphas = [10e-7 , 10e-5 , 10e-3 , 1.0 , 10.0]
    results = get_results(alphas, data)
    kaggle_predictions(results, data)

#def run_question_3():
 #   run_data_image_3()    
#Compute error
def compute_error(accuracy):
    return 1-accuracy

run_data_image_3()