# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 19:19:07 2019

@author: Pantazis
"""
#Load Libraries
import numpy as np
import sklearn
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.multioutput import MultiOutputRegressor
import time
import kaggle
import matplotlib.pyplot as plt
#Read data
def read_data_air_foil():
	print('Reading air foil dataset ...')
	train_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirFoil/train.npy')
	train_x = train_data[:,0:train_data.shape[1]-1]
	train_y = train_data[:,train_data.shape[1]-1:]
	test_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirFoil/test_distribute.npy')
	test_x = test_data
	return (train_x, train_y, test_x)

def read_data_air_quality():
	print('Reading air quality dataset ...')
	train_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirQuality/train.npy')
	train_x = train_data[:,0:train_data.shape[1]-2]
	train_y = train_data[:,train_data.shape[1]-2:train_data.shape[1]]
	test_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirQuality/test_distribute.npy')
	test_x = test_data
	return (train_x, train_y, test_x)
  #CrossValidation
def est_out_of_sample_error(k, data):
    train_x, train_y, test_x = data
    start_time=time.time()
    sample_error=0
    kfold = KFold(5,True,1)
    for train_index, eval_index in kfold.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        model = MultiOutputRegressor(KNeighborsRegressor(n_neighbors=k))
        model.fit(x_train , y_train)
        predicted_y_eval = model.predict(x_eval)
        sample_error += compute_error(predicted_y_eval,y_eval) / 5
    end_time=time.time()
    total_time = end_time - start_time
    return (sample_error, total_time)
#Get errors for each parameter
def get_results(ks, data):
    train_x, train_y, test_x = data
    total_times = []
    sample_errors = []
    for k in ks:
        sample_error , total_time = est_out_of_sample_error(k, data)
        sample_errors.append(sample_error)
        total_times.append(total_time*1000)
    return ks, sample_errors, total_times
#kaggle output
def kaggle_predictions(results, data, name):
    train_x, train_y, test_x = data
    ks, sample_errors, total_times = results
    best_k = ks[np.argmin(sample_errors)]     

    model = MultiOutputRegressor(KNeighborsRegressor(n_neighbors=best_k))
    model.fit(train_x , train_y)
    predict_output = model.predict(test_x)

    kaggle.kaggleize(predict_output, "../Predictions/" + name + "/knn.csv")
# make figure & table
def figures(results, name):
    ks, sample_errors, total_times = results
    #error
    plt.clf()
    fig, ax = plt.subplots()
    titles = ("k", "Estimated Out of Sample Error")
    fig.patch.set_visible(False)
    ax.axis("off")
    ax.table(cellText=np.column_stack([ks, sample_errors]), colLabels=titles, loc="center")
    fig.patch.set_visible(True)
    ax.axis("on")
    plt.savefig("../Figures/"+name+"/knn_errors.png")
    ax.axis("off")
    fig.patch.set_visible(False)
    #times
    plt.clf()
    plt.plot(ks, total_times)
    plt.xlabel("k")
    plt.ylabel("Execution Time")
    plt.savefig("../Figures/"+name+"/knn_time.png")

def run_airfoil():
    data = read_data_air_foil()
    ks = [3, 5,10,20,25]
    results = get_results(ks, data)
    kaggle_predictions(results, data, "AirFoil")
    figures(results, "AirFoil")

def run_airquality():
    data = read_data_air_quality()
    ks = [3, 5,10,20,25]
    results = get_results(ks, data)
    kaggle_predictions(results, data, "AirQuality")
    figures(results, "AirQuality")

def run_question_3():
    run_airfoil()
    run_airquality()

# Compute MAE
def compute_error(predicted_y_eval, y_eval):
	# mean absolute error
	return np.abs(predicted_y_eval - y_eval).mean()
