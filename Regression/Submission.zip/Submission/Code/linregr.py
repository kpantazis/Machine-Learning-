# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 19:19:07 2019

@author: Pantazis
"""
#Load Libraries
import numpy as np
import sklearn
from sklearn.model_selection import KFold
from sklearn.multioutput import MultiOutputRegressor
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
import time
import kaggle
import matplotlib.pyplot as plt

#Read data
def read_data_air_foil():
	print('Reading air foil dataset ...')
	train_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirFoil/train.npy')
	train_x = train_data[:,0:train_data.shape[1]-1]
	train_y = train_data[:,train_data.shape[1]-1:]
	test_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirFoil/test_distribute.npy')
	test_x = test_data
	return (train_x, train_y, test_x)

def read_data_air_quality():
	print('Reading air quality dataset ...')
	train_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirQuality/train.npy')
	train_x = train_data[:,0:train_data.shape[1]-2]
	train_y = train_data[:,train_data.shape[1]-2:train_data.shape[1]]
	test_data = np.load('C:/Users/Pantazis/Desktop/Spring 2019/Machine Learning/HW01/Data/AirQuality/test_distribute.npy')
	test_x = test_data
	return (train_x, train_y, test_x)
#CrossValidation
def est_out_of_sample_error(alpha, data):
    train_x, train_y, test_x = data
    start_time=time.time()
    sample_error_Ridge=0
    sample_error_Lasso=0

    kfold = KFold(5,True,1)
    for train_index, eval_index in kfold.split(train_x,train_y):
        x_train = train_x[train_index]
        y_train = train_y[train_index]
        x_eval = train_x[eval_index]
        y_eval = train_y[eval_index]
        model1 = MultiOutputRegressor(Ridge(alpha))
        model1.fit(x_train , y_train) 
        predicted_y_Ridge = model1.predict(x_eval)
        model2 = MultiOutputRegressor(Lasso(alpha))
        model2.fit(x_train , y_train)
        predicted_y_Lasso = model2.predict(x_eval)
        sample_error_Ridge +=  compute_error(predicted_y_Ridge, y_eval) / 5
        sample_error_Lasso += compute_error(predicted_y_Lasso, y_eval) / 5
    end_time=time.time()
    total_time = ( end_time - start_time ) / 2
    return (sample_error_Ridge , total_time, sample_error_Lasso)
#Get errors for each parameter
def get_results(alphas, data):
    train_x, train_y, test_x = data
    total_times = []
    sample_errors_Ridge = []
    sample_errors_Lasso = []
    for alpha in alphas:
        sample_error_Ridge , total_time , sample_error_Lasso = est_out_of_sample_error(alpha, data)
        sample_errors_Ridge.append(sample_error_Ridge)
        sample_errors_Lasso.append(sample_error_Lasso)
        total_times.append(total_time*1000)
    return alphas, sample_errors_Ridge , sample_errors_Lasso , total_times
#kaggle output
def kaggle_predictions(results, data, name):
    train_x, train_y, test_x = data
    alphas, sample_errors_Ridge, sample_errors_Lasso , total_times = results
    if np.min(sample_errors_Ridge) < np.min(sample_errors_Lasso):
        best_alpha = alphas[np.argmin(sample_errors_Ridge)]
        model = MultiOutputRegressor(Ridge(best_alpha , normalize=True ))
    else:
        best_alpha = alphas[np.argmin(sample_errors_Lasso)]
        model = MultiOutputRegressor(Lasso(best_alpha , normalize=True))
        #model1 = MultiOutputRegressor(Ridge(best_alpha))
    model.fit(train_x , train_y)
    predict_output = model.predict(test_x)
        #model2 = MultiOutputRegressor(Lasso(best_alpha))
        #model2.fit(train_x , train_y)
        #predict_output2 = model2.predict(test_x)

    kaggle.kaggleize(predict_output, "../Predictions/" + name + "/linregr.csv")
    

# make table
def figures(results, name):
    alphas, sample_errors_Ridge, sample_errors_Lasso , total_times = results
    best_penalty = []
    if np.min(sample_errors_Ridge) < np.min(sample_errors_Lasso):
        best_penalty = sample_errors_Ridge
        print("Ridge")
    else:
        best_penalty = sample_errors_Lasso
        print("Lasso")
    #error
    plt.clf()
    fig, ax = plt.subplots()
    titles = ("alpha", "Estimated Out of Sample Error")
    fig.patch.set_visible(False)
    ax.axis("off")
    ax.table(cellText=np.column_stack([alphas, best_penalty]), colLabels=titles, loc="center")
    fig.patch.set_visible(True)
    ax.axis("on")
    plt.savefig("../Figures/"+name+"/bestout_of_2_errors.png")




def run_airfoil():
    data = read_data_air_foil()
    alphas = [10e-7 , 10e-5 , 10e-3 , 1.0 , 10.0]
    results = get_results(alphas, data)
    kaggle_predictions(results, data, "AirFoil")
    figures(results, "AirFoil")

def run_airquality():
    data = read_data_air_quality()
    alphas = [10e-5 , 10e-3 , 1.0 , 10.0]
    results = get_results(alphas, data)
    kaggle_predictions(results, data, "AirQuality")
    figures(results, "AirQuality")

def run_question_4():
    run_airfoil()
    run_airquality()

# Compute MAE
def compute_error(predicted_y_eval, y_eval):
	# mean absolute error
	return np.abs(predicted_y_eval - y_eval).mean()