import decisiontrees
import knn3
import linregr
import kagglecomp

#KNN
knn3.run_question_3()
#DecisionTree
decisiontrees.run_question_1()
#Ridge and Lasso
linregr.run_question_4()
#Question 5
kagglecomp.run_question_5()